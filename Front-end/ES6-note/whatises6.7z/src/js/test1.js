let name = "test1.js";
function call() {
  console.log("you call test1.js function");
}
export { name, call };
