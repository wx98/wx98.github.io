import * as test1 from "./test1.js";
import * as test2 from "./test2.js";

console.log(test1);
console.log(test2);
console.log(test1.name);
console.log(test2.name);
test1.call();
test2.call();
