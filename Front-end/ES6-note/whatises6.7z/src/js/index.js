import * as test from "./test1.js";

console.log(test.name);
test.call();
