let name = "test2.js";
function call() {
  console.log("you call test2.js function");
}
export { name, call };
